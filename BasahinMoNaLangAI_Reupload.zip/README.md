# Basahin Mo Na Lang AI

This is a Streamlit app that summarizes any uploaded PDF book and allows you to ask questions about it in English or Tagalog.
